# Applied JavaScript Activity

A Pen created on CodePen.io. Original URL: [https://codepen.io/kelseyberta/pen/abjmPww](https://codepen.io/kelseyberta/pen/abjmPww).

